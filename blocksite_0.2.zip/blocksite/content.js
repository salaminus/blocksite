// Content script для дополнительной проверки
chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
    if (result.blockingEnabled !== false && result.blockedSites) {
        const currentUrl = window.location.hostname;
        
        const isBlocked = result.blockedSites.some(site => {
            const cleanSite = site.toLowerCase().replace('www.', '');
            const cleanHostname = currentUrl.toLowerCase().replace('www.', '');
            const isSiteMatch = cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
            
            // Проверяем, не отключена ли блокировка
            const isDisabled = result.disabledSites && result.disabledSites.some(disabledSite => {
                const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
                return cleanHostname.includes(cleanDisabled) || cleanDisabled.includes(cleanHostname);
            });
            
            return isSiteMatch && !isDisabled;
        });
        
        if (isBlocked && !window.location.href.includes('blocked.html')) {
            console.log('Content script: блокируем сайт', currentUrl);
            window.location.href = chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(window.location.href);
        }
    }
});