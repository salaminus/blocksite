// Content script для дополнительной проверки
chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
    if (result.blockingEnabled !== false && result.blockedSites && result.blockedSites.length > 0) {
        const currentUrl = window.location.hostname;
        const cleanHostname = currentUrl.toLowerCase().replace('www.', '');
        
        let shouldBlock = false;
        
        // Проверяем каждый заблокированный сайт
        for (const site of result.blockedSites) {
            const cleanSite = site.toLowerCase().replace('www.', '');
            
            // Если домен совпадает
            if (cleanHostname === cleanSite || 
                cleanHostname.endsWith('.' + cleanSite) || 
                cleanSite.endsWith('.' + cleanHostname)) {
                
                // Проверяем, не отключена ли блокировка
                let isDisabled = false;
                for (const disabledSite of result.disabledSites || []) {
                    const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
                    if (cleanSite === cleanDisabled) {
                        isDisabled = true;
                        break;
                    }
                }
                
                // Если не отключен - блокируем
                if (!isDisabled) {
                    shouldBlock = true;
                    break;
                }
            }
        }
        
        if (shouldBlock && !window.location.href.includes('blocked.html')) {
            console.log('Content script: блокируем сайт', currentUrl);
            window.location.href = chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(window.location.href);
        }
    }
});