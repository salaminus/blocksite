document.addEventListener('DOMContentLoaded', function() {
  // ... остальные переменные ...

  // Загружаем данные при открытии
  loadAllData();

  // Функция загрузки всех данных
  function loadAllData() {
    chrome.storage.local.get(['blockingEnabled', 'blockedSites', 'disabledSites'], function(result) {
      console.log('📥 Загружены данные:', result);
      updateBlockingStatus(result.blockingEnabled);
      updateSitesList(result.blockedSites, result.disabledSites);
      updateStats(result.blockedSites, result.disabledSites);
    });
  }

  // Обновление статуса блокировки
  function updateBlockingStatus(isEnabled) {
    const isEnabledBool = isEnabled !== false;
    
    if (isEnabledBool) {
      blockingStatusElement.textContent = 'Активна';
      blockingStatusElement.className = 'status-enabled';
      toggleBlockingOptionsButton.textContent = 'Выключить блокировку';
      toggleBlockingOptionsButton.className = 'btn btn-danger';
    } else {
      blockingStatusElement.textContent = 'Отключена';
      blockingStatusElement.className = 'status-disabled';
      toggleBlockingOptionsButton.textContent = 'Включить блокировку';
      toggleBlockingOptionsButton.className = 'btn btn-primary';
    }
  }

  // Обновление списка сайтов
  function updateSitesList(blockedSites, disabledSites) {
    sitesList.innerHTML = '';
    
    if (!blockedSites || blockedSites.length === 0) {
      const li = document.createElement('li');
      li.textContent = 'Нет заблокированных сайтов';
      li.className = 'empty';
      sitesList.appendChild(li);
      return;
    }

    blockedSites.forEach(site => {
      const isDisabled = disabledSites && disabledSites.includes(site);
      const li = document.createElement('li');
      li.className = isDisabled ? 'site-disabled' : 'site-enabled';
      
      // Чекбокс
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = !isDisabled;
      checkbox.className = 'site-toggle';
      checkbox.addEventListener('change', function() {
        handleSiteToggle(site, this.checked);
      });
      
      // Название сайта
      const siteName = document.createElement('span');
      siteName.textContent = site;
      siteName.className = 'site-name';
      
      // Статус
      const status = document.createElement('span');
      status.textContent = isDisabled ? ' (разрешён)' : ' (заблокирован)';
      status.className = isDisabled ? 'status-allowed' : 'status-blocked';
      
      // Кнопка удаления
      const removeBtn = document.createElement('button');
      removeBtn.textContent = 'Удалить';
      removeBtn.className = 'btn btn-small btn-danger';
      removeBtn.addEventListener('click', function() {
        showPasswordPromptForRemoval(site);
      });
      
      li.appendChild(checkbox);
      li.appendChild(siteName);
      li.appendChild(status);
      li.appendChild(removeBtn);
      sitesList.appendChild(li);
    });
  }

  // Обработка переключения чекбокса
  function handleSiteToggle(site, enabled) {
    console.log(`🔄 Переключение сайта ${site} на ${enabled ? 'включен' : 'выключен'}`);
    
    chrome.storage.local.get(['disabledSites'], function(result) {
      let disabledSites = result.disabledSites || [];
      
      if (enabled) {
        // Включаем блокировку - удаляем из disabledSites
        disabledSites = disabledSites.filter(s => s !== site);
      } else {
        // Выключаем блокировку - добавляем в disabledSites
        if (!disabledSites.includes(site)) {
          disabledSites.push(site);
        }
      }
      
      // Сохраняем изменения
      chrome.storage.local.set({ disabledSites: disabledSites }, function() {
        console.log('💾 Сохранены disabledSites:', disabledSites);
        
        // Принудительно обновляем все вкладки
        forceRefreshAllTabs();
        
        // Показываем сообщение
        showMessage(
          `Сайт ${site} ${enabled ? 'заблокирован' : 'разрешен'}`,
          'success'
        );
        
        // Обновляем интерфейс
        loadAllData();
      });
    });
  }

  // Принудительное обновление всех вкладок
  function forceRefreshAllTabs() {
    chrome.tabs.query({}, function(tabs) {
      tabs.forEach(function(tab) {
        if (tab.url && !tab.url.includes('blocked.html') && !tab.url.startsWith('chrome://')) {
          chrome.tabs.reload(tab.id, { bypassCache: true });
        }
      });
    });
  }

  // Включить все сайты
  function showPasswordPromptForEnableAll() {
    const password = prompt('Введите пароль для включения блокировки всех сайтов:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          // Очищаем disabledSites - ВКЛЮЧАЕМ ВСЕ
          chrome.storage.local.set({ disabledSites: [] }, function() {
            console.log('✅ Включены все сайты');
            forceRefreshAllTabs();
            showMessage('Блокировка всех сайтов включена', 'success');
            loadAllData();
          });
        } else {
          alert('Неверный пароль!');
        }
      });
    }
  }

  // Выключить все сайты
  function showPasswordPromptForDisableAll() {
    const password = prompt('Введите пароль для выключения блокировки всех сайтов:');
    if (password !== null) {
      chrome.storage.local.get(['password', 'blockedSites'], function(result) {
        if (result.password === password) {
          // Копируем ВСЕ заблокированные сайты в disabledSites
          const allSitesToDisable = [...(result.blockedSites || [])];
          chrome.storage.local.set({ disabledSites: allSitesToDisable }, function() {
            console.log('❌ Выключены все сайты:', allSitesToDisable);
            forceRefreshAllTabs();
            showMessage('Блокировка всех сайтов выключена', 'success');
            loadAllData();
          });
        } else {
          alert('Неверный пароль!');
        }
      });
    }
  }

  // Обновление статистики
  function updateStats(blockedSites, disabledSites) {
    const totalBlocked = blockedSites ? blockedSites.length : 0;
    const totalDisabled = disabledSites ? disabledSites.length : 0;
    
    totalBlockedElement.textContent = totalBlocked;
    totalDisabledElement.textContent = totalDisabled;
  }


});