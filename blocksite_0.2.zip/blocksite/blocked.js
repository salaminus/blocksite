document.addEventListener('DOMContentLoaded', function() {
  const blockedUrlElement = document.getElementById('blockedUrl');
  const passwordInput = document.getElementById('passwordInput');
  const unlockButton = document.getElementById('unlockButton');
  const backButton = document.getElementById('backButton');
  const messageElement = document.getElementById('message');

  // Получаем URL из параметров
  const urlParams = new URLSearchParams(window.location.search);
  const blockedUrl = urlParams.get('url');
  let originalHostname = '';
  
  if (blockedUrl) {
    try {
      const urlObj = new URL(blockedUrl);
      originalHostname = urlObj.hostname;
      blockedUrlElement.textContent = urlObj.hostname;
    } catch (e) {
      originalHostname = blockedUrl;
      blockedUrlElement.textContent = blockedUrl;
    }
  }

  // Разблокировка по паролю
  unlockButton.addEventListener('click', function() {
    unlockWebsite();
  });

  // Разблокировка по Enter
  passwordInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      unlockWebsite();
    }
  });

  // Кнопка "Назад"
  backButton.addEventListener('click', function() {
    history.back();
  });

  // Автофокус на поле пароля
  passwordInput.focus();

  function unlockWebsite() {
    const password = passwordInput.value;
    
    if (!password) {
      showMessage('Введите пароль', 'error');
      return;
    }
    
    chrome.storage.local.get(['password', 'blockedSites', 'disabledSites'], function(result) {
      if (result.password === password) {
        // НЕ удаляем сайт из blockedSites, а добавляем в disabledSites для временного доступа
        const disabledSites = result.disabledSites || [];
        const blockedSites = result.blockedSites || [];
        
        // Находим соответствующий заблокированный сайт
        const matchedBlockedSite = findMatchingBlockedSite(originalHostname, blockedSites);
        
        if (matchedBlockedSite && !disabledSites.includes(matchedBlockedSite)) {
          // Добавляем сайт в disabledSites для временного разрешения
          disabledSites.push(matchedBlockedSite);
          
          chrome.storage.local.set({ disabledSites: disabledSites }, function() {
            showMessage('Доступ к сайту предоставлен! Перенаправление...', 'success');
            
            // Переходим на оригинальный URL через короткую задержку
            setTimeout(() => {
              window.location.href = blockedUrl;
            }, 1000);
          });
        } else {
          // Если сайт уже разрешен или не найден, просто переходим
          showMessage('Перенаправление...', 'success');
          setTimeout(() => {
            window.location.href = blockedUrl;
          }, 1000);
        }
      } else {
        showMessage('Неверный пароль', 'error');
        passwordInput.value = '';
        passwordInput.focus();
      }
    });
  }

  // Функция для поиска соответствующего заблокированного сайта
  function findMatchingBlockedSite(hostname, blockedSites) {
    const cleanHostname = hostname.toLowerCase().replace('www.', '');
    
    for (const site of blockedSites) {
      const cleanSite = site.toLowerCase().replace('www.', '');
      if (cleanHostname === cleanSite || cleanHostname.endsWith('.' + cleanSite)) {
        return site; // Возвращаем оригинальное название из blockedSites
      }
    }
    return null;
  }

  function showMessage(text, type) {
    messageElement.textContent = text;
    messageElement.className = `message ${type}`;
  }
});