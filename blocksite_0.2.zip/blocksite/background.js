// Инициализация хранилища по умолчанию
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'password', 'disabledSites'], function(result) {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
    if (result.blockingEnabled === undefined) {
      chrome.storage.local.set({ blockingEnabled: true });
    }
    if (!result.password) {
      chrome.storage.local.set({ password: 'admin123' });
    }
    if (!result.disabledSites) {
      chrome.storage.local.set({ disabledSites: [] });
    }
  });
});

// Упрощенная функция для проверки блокировки сайта
function isSiteBlocked(hostname, blockedSites, disabledSites) {
  if (!blockedSites || blockedSites.length === 0) {
    return false;
  }

  const cleanHostname = hostname.toLowerCase().replace('www.', '');
  
  // Проверяем каждый заблокированный сайт
  for (const site of blockedSites) {
    const cleanSite = site.toLowerCase().replace('www.', '');
    
    // Если домен совпадает
    if (cleanHostname === cleanSite || 
        cleanHostname.endsWith('.' + cleanSite) || 
        cleanSite.endsWith('.' + cleanHostname)) {
      
      // Проверяем, не отключена ли блокировка для этого сайта
      let isDisabled = false;
      for (const disabledSite of disabledSites || []) {
        const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
        if (cleanSite === cleanDisabled) {
          isDisabled = true;
          break;
        }
      }
      
      // Если не отключен - блокируем
      if (!isDisabled) {
        return true;
      }
    }
  }
  
  return false;
}

// Перехват навигации
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
  // Пропускаем внутренние страницы расширения
  if (details.url.startsWith('chrome-extension://') && details.url.includes('blocked.html')) {
    return;
  }
  
  if (details.frameId === 0) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      // Проверяем, включена ли глобальная блокировка
      if (result.blockingEnabled !== false) {
        try {
          const url = new URL(details.url);
          const hostname = url.hostname;
          
          if (isSiteBlocked(hostname, result.blockedSites, result.disabledSites)) {
            console.log('Блокируем сайт:', hostname);
            // Перенаправление на страницу блокировки
            chrome.tabs.update(details.tabId, {
              url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(details.url)
            });
          }
        } catch (e) {
          console.error('Ошибка при обработке URL:', e);
        }
      }
    });
  }
});

// Дополнительная проверка при обновлении вкладки
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'loading' && tab.url && !tab.url.includes('blocked.html')) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      if (result.blockingEnabled !== false) {
        try {
          const url = new URL(tab.url);
          const hostname = url.hostname;
          
          if (isSiteBlocked(hostname, result.blockedSites, result.disabledSites)) {
            console.log('Блокируем сайт при обновлении:', hostname);
            chrome.tabs.update(tabId, {
              url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(tab.url)
            });
          }
        } catch (e) {
          console.error('Ошибка при обработке URL:', e);
        }
      }
    });
  }
});