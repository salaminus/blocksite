// Инициализация хранилища по умолчанию
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'password', 'disabledSites'], function(result) {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
    if (result.blockingEnabled === undefined) {
      chrome.storage.local.set({ blockingEnabled: true });
    }
    if (!result.password) {
      chrome.storage.local.set({ password: 'admin123' });
    }
    if (!result.disabledSites) {
      chrome.storage.local.set({ disabledSites: [] });
    }
  });
});

// Функция для проверки блокировки сайта
function isSiteBlocked(hostname, blockedSites, disabledSites) {
  if (!blockedSites || blockedSites.length === 0) {
    return false;
  }

  const cleanHostname = hostname.toLowerCase().replace('www.', '');
  
  // Ищем сайт в заблокированных
  const blockedSite = blockedSites.find(site => {
    const cleanSite = site.toLowerCase().replace('www.', '');
    return cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
  });

  if (!blockedSite) {
    return false;
  }

  // Проверяем, не отключена ли блокировка для этого сайта
  const isDisabled = disabledSites && disabledSites.some(disabledSite => {
    const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
    const cleanBlocked = blockedSite.toLowerCase().replace('www.', '');
    return cleanHostname.includes(cleanDisabled) || cleanDisabled.includes(cleanHostname) ||
           cleanBlocked.includes(cleanDisabled) || cleanDisabled.includes(cleanBlocked);
  });

  return !isDisabled;
}

// Перехват навигации
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
  // Пропускаем внутренние страницы расширения
  if (details.url.startsWith('chrome-extension://') && details.url.includes('blocked.html')) {
    return;
  }
  
  if (details.frameId === 0) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      // Проверяем, включена ли глобальная блокировка
      if (result.blockingEnabled !== false) {
        try {
          const url = new URL(details.url);
          const hostname = url.hostname;
          
          if (isSiteBlocked(hostname, result.blockedSites, result.disabledSites)) {
            console.log('Блокируем сайт:', hostname);
            console.log('Заблокированные сайты:', result.blockedSites);
            console.log('Отключенные сайты:', result.disabledSites);
            // Перенаправление на страницу блокировки
            chrome.tabs.update(details.tabId, {
              url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(details.url)
            });
          }
        } catch (e) {
          console.error('Ошибка при обработке URL:', e);
        }
      }
    });
  }
});

// Дополнительная проверка при обновлении вкладки
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'loading' && tab.url && !tab.url.includes('blocked.html')) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      if (result.blockingEnabled !== false) {
        try {
          const url = new URL(tab.url);
          const hostname = url.hostname;
          
          if (isSiteBlocked(hostname, result.blockedSites, result.disabledSites)) {
            console.log('Блокируем сайт при обновлении:', hostname);
            chrome.tabs.update(tabId, {
              url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(tab.url)
            });
          }
        } catch (e) {
          console.error('Ошибка при обработке URL:', e);
        }
      }
    });
  }
});

// Слушатель изменений в хранилище для отладки
chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (namespace === 'local') {
    console.log('Изменения в хранилище:', changes);
  }
});