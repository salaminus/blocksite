document.addEventListener('DOMContentLoaded', function() {
  const blockedUrlElement = document.getElementById('blockedUrl');
  const passwordInput = document.getElementById('passwordInput');
  const unlockButton = document.getElementById('unlockButton');
  const backButton = document.getElementById('backButton');
  const messageElement = document.getElementById('message');

  // Получаем URL из параметров
  const urlParams = new URLSearchParams(window.location.search);
  const blockedUrl = urlParams.get('url');
  
  if (blockedUrl) {
    try {
      const urlObj = new URL(blockedUrl);
      blockedUrlElement.textContent = urlObj.hostname;
    } catch (e) {
      blockedUrlElement.textContent = blockedUrl;
    }
  }

  // Разблокировка по паролю
  unlockButton.addEventListener('click', function() {
    const password = passwordInput.value;
    
    if (!password) {
      showMessage('Введите пароль', 'error');
      return;
    }
    
    chrome.storage.local.get(['password'], function(result) {
      if (result.password === password) {
        // Временно разблокируем сайт
        chrome.storage.local.get(['blockedSites'], function(result) {
          const currentHostname = new URL(blockedUrl).hostname;
          const updatedSites = result.blockedSites.filter(site => !currentHostname.includes(site));
          
          chrome.storage.local.set({ blockedSites: updatedSites }, function() {
            // Переходим на оригинальный URL
            window.location.href = blockedUrl;
          });
        });
      } else {
        showMessage('Неверный пароль', 'error');
        passwordInput.value = '';
        passwordInput.focus();
      }
    });
  });

  // Разблокировка по Enter
  passwordInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      unlockButton.click();
    }
  });

  // Кнопка "Назад"
  backButton.addEventListener('click', function() {
    history.back();
  });

  // Автофокус на поле пароля
  passwordInput.focus();

  function showMessage(text, type) {
    messageElement.textContent = text;
    messageElement.className = `message ${type}`;
    setTimeout(() => {
      messageElement.textContent = '';
      messageElement.className = 'message';
    }, 3000);
  }
});