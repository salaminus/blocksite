document.addEventListener('DOMContentLoaded', function() {
  const blockedUrlElement = document.getElementById('blockedUrl');
  const passwordInput = document.getElementById('passwordInput');
  const unlockButton = document.getElementById('unlockButton');
  const backButton = document.getElementById('backButton');
  const messageElement = document.getElementById('message');

  // Получаем URL из параметров
  const urlParams = new URLSearchParams(window.location.search);
  const blockedUrl = urlParams.get('url');
  let originalHostname = '';
  
  if (blockedUrl) {
    try {
      const urlObj = new URL(blockedUrl);
      originalHostname = urlObj.hostname;
      blockedUrlElement.textContent = urlObj.hostname;
    } catch (e) {
      originalHostname = blockedUrl;
      blockedUrlElement.textContent = blockedUrl;
    }
  }

  // Разблокировка по паролю
  unlockButton.addEventListener('click', function() {
    unlockWebsite();
  });

  // Разблокировка по Enter
  passwordInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      unlockWebsite();
    }
  });

  // Кнопка "Назад"
  backButton.addEventListener('click', function() {
    history.back();
  });

  // Автофокус на поле пароля
  passwordInput.focus();

  function unlockWebsite() {
    const password = passwordInput.value;
    
    if (!password) {
      showMessage('Введите пароль', 'error');
      return;
    }
    
    chrome.storage.local.get(['password', 'blockedSites'], function(result) {
      if (result.password === password) {
        // Удаляем сайт из списка заблокированных
        const updatedSites = result.blockedSites.filter(site => {
          // Удаляем все варианты домена
          const cleanHostname = originalHostname.replace('www.', '');
          const cleanSite = site.replace('www.', '');
          return !cleanHostname.includes(cleanSite) && !cleanSite.includes(cleanHostname);
        });
        
        chrome.storage.local.set({ blockedSites: updatedSites }, function() {
          showMessage('Сайт разблокирован! Перенаправление...', 'success');
          
          // Переходим на оригинальный URL через короткую задержку
          setTimeout(() => {
            window.location.href = blockedUrl;
          }, 1000);
        });
      } else {
        showMessage('Неверный пароль', 'error');
        passwordInput.value = '';
        passwordInput.focus();
      }
    });
  }

  function showMessage(text, type) {
    messageElement.textContent = text;
    messageElement.className = `message ${type}`;
  }
});