document.addEventListener('DOMContentLoaded', function() {
  const statusText = document.getElementById('statusText');
  const toggleButton = document.getElementById('toggleBlocking');
  const openOptionsButton = document.getElementById('openOptions');
  const quickSiteInput = document.getElementById('quickSite');
  const addSiteButton = document.getElementById('addSite');
  const blockedSitesList = document.getElementById('blockedSites');
  const enableAllButton = document.getElementById('enableAll');
  const disableAllButton = document.getElementById('disableAll');

  // Загрузка состояния блокировки
  chrome.storage.local.get(['blockingEnabled'], function(result) {
    const isEnabled = result.blockingEnabled !== false;
    updateToggleButton(isEnabled);
  });

  // Переключение блокировки
  toggleButton.addEventListener('click', function() {
    chrome.storage.local.get(['blockingEnabled'], function(result) {
      const currentState = result.blockingEnabled !== false;
      
      if (currentState) {
        // Если пытаемся выключить блокировку - запрашиваем пароль
        showPasswordPromptForDisable();
      } else {
        // Включение блокировки без пароля
        chrome.storage.local.set({ blockingEnabled: true }, function() {
          updateToggleButton(true);
          loadBlockedSites();
        });
      }
    });
  });

  // Открытие настроек
  openOptionsButton.addEventListener('click', function() {
    chrome.runtime.openOptionsPage();
  });

  // Быстрое добавление сайта
  addSiteButton.addEventListener('click', function() {
    const site = quickSiteInput.value.trim();
    if (site) {
      showPasswordPromptForAddition(site);
    }
  });

  // Добавление по Enter
  quickSiteInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      const site = quickSiteInput.value.trim();
      if (site) {
        showPasswordPromptForAddition(site);
      }
    }
  });

  // Включить все сайты
  enableAllButton.addEventListener('click', function() {
    showPasswordPromptForEnableAll();
  });

  // Выключить все сайты
  disableAllButton.addEventListener('click', function() {
    showPasswordPromptForDisableAll();
  });

  // Загрузка списка заблокированных сайтов
  loadBlockedSites();

  function updateToggleButton(isEnabled) {
    if (isEnabled) {
      toggleButton.textContent = 'Выключить блокировку';
      toggleButton.classList.add('btn-danger');
      toggleButton.classList.remove('btn-primary');
      statusText.textContent = 'Блокировка активна';
    } else {
      toggleButton.textContent = 'Включить блокировку';
      toggleButton.classList.add('btn-primary');
      toggleButton.classList.remove('btn-danger');
      statusText.textContent = 'Блокировка отключена';
    }
  }

  function showPasswordPromptForAddition(site) {
    const password = prompt('Введите пароль для добавления сайта в блокировку:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          addSiteToBlockList(site);
          quickSiteInput.value = '';
        } else {
          alert('Неверный пароль! Сайт не добавлен.');
        }
      });
    }
  }

  function addSiteToBlockList(site) {
    chrome.storage.local.get(['blockedSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      if (!blockedSites.includes(site)) {
        blockedSites.push(site);
        chrome.storage.local.set({ blockedSites: blockedSites }, function() {
          loadBlockedSites();
          showTempMessage('Сайт добавлен в блокировку', 'success');
        });
      } else {
        showTempMessage('Сайт уже в списке блокировки', 'error');
      }
    });
  }

  function loadBlockedSites() {
    chrome.storage.local.get(['blockedSites', 'disabledSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      const disabledSites = result.disabledSites || [];
      
      blockedSitesList.innerHTML = '';
      
      if (blockedSites.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'Нет заблокированных сайтов';
        li.className = 'empty';
        blockedSitesList.appendChild(li);
      } else {
        blockedSites.forEach(site => {
          const isDisabled = disabledSites.includes(site);
          const li = document.createElement('li');
          li.className = isDisabled ? 'site-disabled' : 'site-enabled';
          
          // Переключатель
          const toggle = document.createElement('input');
          toggle.type = 'checkbox';
          toggle.checked = !isDisabled;
          toggle.className = 'site-toggle';
          toggle.addEventListener('change', function() {
            if (this.checked) {
              // Включение блокировки - без пароля
              toggleSiteBlocking(site, true);
            } else {
              // Выключение блокировки - с паролем
              showPasswordPromptForToggle(site, false);
            }
          });
          
          // Название сайта
          const siteName = document.createElement('span');
          siteName.textContent = site;
          siteName.className = 'site-name';
          
          // Кнопка удаления
          const removeBtn = document.createElement('button');
          removeBtn.textContent = '×';
          removeBtn.className = 'remove-btn';
          removeBtn.addEventListener('click', function() {
            showPasswordPromptForRemoval(site);
          });
          
          li.appendChild(toggle);
          li.appendChild(siteName);
          li.appendChild(removeBtn);
          blockedSitesList.appendChild(li);
        });
      }
    });
  }

  function showPasswordPromptForToggle(site, enabled) {
    const action = enabled ? 'включения' : 'выключения';
    const password = prompt(`Введите пароль для ${action} блокировки сайта ${site}:`);
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          toggleSiteBlocking(site, enabled);
        } else {
          alert('Неверный пароль! Действие отменено.');
          // Возвращаем переключатель в исходное состояние
          loadBlockedSites();
        }
      });
    } else {
      // Пользователь отменил ввод пароля - возвращаем переключатель
      loadBlockedSites();
    }
  }

  function toggleSiteBlocking(site, enabled) {
    chrome.storage.local.get(['disabledSites'], function(result) {
      let disabledSites = result.disabledSites || [];
      
      if (enabled) {
        // Включаем блокировку - удаляем из disabledSites
        disabledSites = disabledSites.filter(s => s !== site);
      } else {
        // Выключаем блокировку - добавляем в disabledSites
        if (!disabledSites.includes(site)) {
          disabledSites.push(site);
        }
      }
      
      chrome.storage.local.set({ disabledSites: disabledSites }, function() {
        loadBlockedSites();
        showTempMessage(
          enabled ? `Блокировка ${site} включена` : `Блокировка ${site} отключена`, 
          'success'
        );
      });
    });
  }

  function showPasswordPromptForEnableAll() {
    const password = prompt('Введите пароль для включения блокировки всех сайтов:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          chrome.storage.local.set({ disabledSites: [] }, function() {
            loadBlockedSites();
            showTempMessage('Блокировка всех сайтов включена', 'success');
          });
        } else {
          alert('Неверный пароль! Действие отменено.');
        }
      });
    }
  }

  function showPasswordPromptForDisableAll() {
    const password = prompt('Введите пароль для выключения блокировки всех сайтов:');
    if (password !== null) {
      chrome.storage.local.get(['password', 'blockedSites'], function(result) {
        if (result.password === password) {
          const blockedSites = result.blockedSites || [];
          chrome.storage.local.set({ disabledSites: blockedSites }, function() {
            loadBlockedSites();
            showTempMessage('Блокировка всех сайтов выключена', 'success');
          });
        } else {
          alert('Неверный пароль! Действие отменено.');
        }
      });
    }
  }

  function showPasswordPromptForDisable() {
    const password = prompt('Введите пароль для отключения блокировки:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          chrome.storage.local.set({ blockingEnabled: false }, function() {
            updateToggleButton(false);
            loadBlockedSites();
          });
        } else {
          alert('Неверный пароль! Блокировка остается активной.');
        }
      });
    }
  }

  function showPasswordPromptForRemoval(site) {
    const password = prompt('Введите пароль для удаления сайта из списка заблокированных:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          removeSiteFromBlockList(site);
        } else {
          alert('Неверный пароль!');
        }
      });
    }
  }

  function removeSiteFromBlockList(site) {
    chrome.storage.local.get(['blockedSites', 'disabledSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      const disabledSites = result.disabledSites || [];
      
      const index = blockedSites.indexOf(site);
      if (index > -1) {
        blockedSites.splice(index, 1);
        // Также удаляем из disabledSites если там есть
        const disabledIndex = disabledSites.indexOf(site);
        if (disabledIndex > -1) {
          disabledSites.splice(disabledIndex, 1);
        }
        
        chrome.storage.local.set({ 
          blockedSites: blockedSites,
          disabledSites: disabledSites 
        }, function() {
          loadBlockedSites();
          showTempMessage('Сайт удален из блокировки', 'success');
        });
      }
    });
  }

  function showTempMessage(text, type) {
    const message = document.createElement('div');
    message.textContent = text;
    message.className = `temp-message ${type}`;
    message.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      padding: 10px 15px;
      border-radius: 4px;
      color: white;
      font-weight: bold;
      z-index: 10000;
      ${type === 'success' ? 'background: #27ae60;' : 'background: #e74c3c;'}
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
      if (document.body.contains(message)) {
        document.body.removeChild(message);
      }
    }, 3000);
  }
});