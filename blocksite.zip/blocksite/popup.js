document.addEventListener('DOMContentLoaded', function() {
  const statusText = document.getElementById('statusText');
  const toggleButton = document.getElementById('toggleBlocking');
  const openOptionsButton = document.getElementById('openOptions');
  const quickSiteInput = document.getElementById('quickSite');
  const addSiteButton = document.getElementById('addSite');
  const blockedSitesList = document.getElementById('blockedSites');

  // Загрузка состояния блокировки
  chrome.storage.local.get(['blockingEnabled'], function(result) {
    const isEnabled = result.blockingEnabled !== false;
    updateToggleButton(isEnabled);
  });

  // Переключение блокировки
  toggleButton.addEventListener('click', function() {
    chrome.storage.local.get(['blockingEnabled'], function(result) {
      const currentState = result.blockingEnabled !== false;
      
      if (currentState) {
        // Если пытаемся выключить блокировку - запрашиваем пароль
        showPasswordPromptForDisable();
      } else {
        // Включение блокировки без пароля
        chrome.storage.local.set({ blockingEnabled: true }, function() {
          updateToggleButton(true);
        });
      }
    });
  });

  // Открытие настроек
  openOptionsButton.addEventListener('click', function() {
    chrome.runtime.openOptionsPage();
  });

  // Быстрое добавление сайта
  addSiteButton.addEventListener('click', function() {
    const site = quickSiteInput.value.trim();
    if (site) {
      addSiteToBlockList(site);
      quickSiteInput.value = '';
    }
  });

  // Добавление по Enter
  quickSiteInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      addSiteButton.click();
    }
  });

  // Загрузка списка заблокированных сайтов
  loadBlockedSites();

  function updateToggleButton(isEnabled) {
    if (isEnabled) {
      toggleButton.textContent = 'Выключить блокировку';
      toggleButton.classList.add('btn-danger');
      toggleButton.classList.remove('btn-primary');
      statusText.textContent = 'Блокировка активна';
    } else {
      toggleButton.textContent = 'Включить блокировку';
      toggleButton.classList.add('btn-primary');
      toggleButton.classList.remove('btn-danger');
      statusText.textContent = 'Блокировка отключена';
    }
  }

  function addSiteToBlockList(site) {
    chrome.storage.local.get(['blockedSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      if (!blockedSites.includes(site)) {
        blockedSites.push(site);
        chrome.storage.local.set({ blockedSites: blockedSites }, function() {
          loadBlockedSites();
        });
      }
    });
  }

  function loadBlockedSites() {
    chrome.storage.local.get(['blockedSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      blockedSitesList.innerHTML = '';
      
      if (blockedSites.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'Нет заблокированных сайтов';
        li.className = 'empty';
        blockedSitesList.appendChild(li);
      } else {
        blockedSites.forEach(site => {
          const li = document.createElement('li');
          li.textContent = site;
          
          const removeBtn = document.createElement('button');
          removeBtn.textContent = '×';
          removeBtn.className = 'remove-btn';
          removeBtn.addEventListener('click', function() {
            showPasswordPromptForRemoval(site);
          });
          
          li.appendChild(removeBtn);
          blockedSitesList.appendChild(li);
        });
      }
    });
  }

  function showPasswordPromptForDisable() {
    const password = prompt('Введите пароль для отключения блокировки:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          chrome.storage.local.set({ blockingEnabled: false }, function() {
            updateToggleButton(false);
          });
        } else {
          alert('Неверный пароль! Блокировка остается активной.');
        }
      });
    }
  }

  function showPasswordPromptForRemoval(site) {
    const password = prompt('Введите пароль для удаления сайта из списка заблокированных:');
    if (password !== null) {
      chrome.storage.local.get(['password'], function(result) {
        if (result.password === password) {
          removeSiteFromBlockList(site);
        } else {
          alert('Неверный пароль!');
        }
      });
    }
  }

  function removeSiteFromBlockList(site) {
    chrome.storage.local.get(['blockedSites'], function(result) {
      const blockedSites = result.blockedSites || [];
      const index = blockedSites.indexOf(site);
      if (index > -1) {
        blockedSites.splice(index, 1);
        chrome.storage.local.set({ blockedSites: blockedSites }, function() {
          loadBlockedSites();
        });
      }
    });
  }
});