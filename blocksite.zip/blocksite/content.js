// Простая проверка на стороне контента
chrome.storage.local.get(['blockedSites', 'blockingEnabled'], function(result) {
  if (result.blockingEnabled !== false && result.blockedSites) {
    const currentUrl = window.location.hostname.toLowerCase();
    
    const isBlocked = result.blockedSites.some(site => {
      const cleanSite = site.toLowerCase().replace('www.', '');
      const cleanHostname = currentUrl.replace('www.', '');
      return cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
    });
    
    if (isBlocked && !window.location.href.includes('blocked.html')) {
      // Перенаправляем на страницу блокировки
      window.location.href = chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(window.location.href);
    }
  }
});