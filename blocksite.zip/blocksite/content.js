// Content script для блокировки доступа к странице
chrome.storage.local.get(['blockedSites', 'blockingEnabled'], function(result) {
  if (result.blockingEnabled !== false && result.blockedSites) {
    const currentUrl = window.location.hostname;
    
    const isBlocked = result.blockedSites.some(site => {
      return currentUrl.includes(site) || site.includes(currentUrl);
    });
    
    if (isBlocked) {
      // Перенаправляем на страницу блокировки
      window.location.href = chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(window.location.href);
    }
  }
});