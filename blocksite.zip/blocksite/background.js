// Инициализация хранилища по умолчанию
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'password'], function(result) {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
    if (result.blockingEnabled === undefined) {
      chrome.storage.local.set({ blockingEnabled: true });
    }
    if (!result.password) {
      // Установка пароля по умолчанию
      chrome.storage.local.set({ password: 'admin123' });
    }
  });
});

// Перехват навигации
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
  if (details.frameId === 0) { // Только для основного фрейма
    chrome.storage.local.get(['blockedSites', 'blockingEnabled'], function(result) {
      // Проверяем, включена ли блокировка
      if (result.blockingEnabled !== false && result.blockedSites) {
        const url = new URL(details.url);
        const hostname = url.hostname;
        
        // Проверка, заблокирован ли сайт
        const isBlocked = result.blockedSites.some(site => {
          return hostname.includes(site) || site.includes(hostname);
        });
        
        if (isBlocked) {
          // Перенаправление на страницу блокировки
          chrome.tabs.update(details.tabId, {
            url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(details.url)
          });
        }
      }
    });
  }
});