// Инициализация хранилища по умолчанию
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'password', 'disabledSites'], function(result) {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
    if (result.blockingEnabled === undefined) {
      chrome.storage.local.set({ blockingEnabled: true });
    }
    if (!result.password) {
      chrome.storage.local.set({ password: 'admin123' });
    }
    if (!result.disabledSites) {
      chrome.storage.local.set({ disabledSites: [] });
    }
  });
});

// Перехват навигации
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
  // Пропускаем внутренние страницы расширения
  if (details.url.startsWith('chrome-extension://') && details.url.includes('blocked.html')) {
    return;
  }
  
  if (details.frameId === 0) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      // Проверяем, включена ли глобальная блокировка
      if (result.blockingEnabled !== false && result.blockedSites && result.blockedSites.length > 0) {
        const url = new URL(details.url);
        const hostname = url.hostname.toLowerCase();
        
        // Проверка, заблокирован ли сайт и не отключена ли его блокировка
        const isBlocked = result.blockedSites.some(site => {
          const cleanSite = site.toLowerCase().replace('www.', '');
          const cleanHostname = hostname.replace('www.', '');
          const isSiteMatch = cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
          
          // Проверяем, не отключена ли блокировка для этого сайта
          const isDisabled = result.disabledSites && result.disabledSites.some(disabledSite => {
            const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
            return cleanHostname.includes(cleanDisabled) || cleanDisabled.includes(cleanHostname);
          });
          
          return isSiteMatch && !isDisabled;
        });
        
        if (isBlocked) {
          console.log('Блокируем сайт:', hostname);
          // Перенаправление на страницу блокировки
          chrome.tabs.update(details.tabId, {
            url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(details.url)
          });
        }
      }
    });
  }
});

// Дополнительная проверка при обновлении вкладки
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'loading') {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'disabledSites'], function(result) {
      if (result.blockingEnabled !== false && result.blockedSites && result.blockedSites.length > 0) {
        const url = new URL(tab.url);
        const hostname = url.hostname.toLowerCase();
        
        const isBlocked = result.blockedSites.some(site => {
          const cleanSite = site.toLowerCase().replace('www.', '');
          const cleanHostname = hostname.replace('www.', '');
          const isSiteMatch = cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
          
          const isDisabled = result.disabledSites && result.disabledSites.some(disabledSite => {
            const cleanDisabled = disabledSite.toLowerCase().replace('www.', '');
            return cleanHostname.includes(cleanDisabled) || cleanDisabled.includes(cleanHostname);
          });
          
          return isSiteMatch && !isDisabled;
        });
        
        if (isBlocked && !tab.url.includes('blocked.html')) {
          chrome.tabs.update(tabId, {
            url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(tab.url)
          });
        }
      }
    });
  }
});