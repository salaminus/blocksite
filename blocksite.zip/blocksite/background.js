// Инициализация хранилища по умолчанию
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.get(['blockedSites', 'blockingEnabled', 'password'], function(result) {
    if (!result.blockedSites) {
      chrome.storage.local.set({ blockedSites: [] });
    }
    if (result.blockingEnabled === undefined) {
      chrome.storage.local.set({ blockingEnabled: true });
    }
    if (!result.password) {
      chrome.storage.local.set({ password: 'admin123' });
    }
  });
});

// Перехват навигации - УПРОЩЕННАЯ ВЕРСИЯ
chrome.webNavigation.onBeforeNavigate.addListener(function(details) {
  // Пропускаем внутренние страницы расширения
  if (details.url.startsWith('chrome-extension://') && details.url.includes('blocked.html')) {
    return;
  }
  
  if (details.frameId === 0) {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled'], function(result) {
      // Проверяем, включена ли блокировка
      if (result.blockingEnabled !== false && result.blockedSites && result.blockedSites.length > 0) {
        const url = new URL(details.url);
        const hostname = url.hostname.toLowerCase();
        
        // Проверка, заблокирован ли сайт
        const isBlocked = result.blockedSites.some(site => {
          const cleanSite = site.toLowerCase().replace('www.', '');
          const cleanHostname = hostname.replace('www.', '');
          return cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
        });
        
        if (isBlocked) {
          console.log('Блокируем сайт:', hostname);
          // Перенаправление на страницу блокировки
          chrome.tabs.update(details.tabId, {
            url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(details.url)
          });
        }
      }
    });
  }
});

// Дополнительная проверка при обновлении вкладки
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'loading') {
    chrome.storage.local.get(['blockedSites', 'blockingEnabled'], function(result) {
      if (result.blockingEnabled !== false && result.blockedSites && result.blockedSites.length > 0) {
        const url = new URL(tab.url);
        const hostname = url.hostname.toLowerCase();
        
        const isBlocked = result.blockedSites.some(site => {
          const cleanSite = site.toLowerCase().replace('www.', '');
          const cleanHostname = hostname.replace('www.', '');
          return cleanHostname.includes(cleanSite) || cleanSite.includes(cleanHostname);
        });
        
        if (isBlocked && !tab.url.includes('blocked.html')) {
          chrome.tabs.update(tabId, {
            url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(tab.url)
          });
        }
      }
    });
  }
});