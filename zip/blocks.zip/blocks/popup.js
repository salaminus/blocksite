document.addEventListener('DOMContentLoaded', function() {
  const statusDiv = document.getElementById('status');
  const passwordInput = document.getElementById('password');
  const unblockBtn = document.getElementById('unblockBtn');
  const blockBtn = document.getElementById('blockBtn');
  const errorDiv = document.getElementById('error');
  const unblockSection = document.getElementById('unblockSection');
  const blockSection = document.getElementById('blockSection');

  // Проверяем текущий статус
  chrome.runtime.sendMessage({action: "checkStatus"}, (response) => {
    updateUI(response.isBlocked);
  });

  // Обработчик кнопки отключения блокировки
  unblockBtn.addEventListener('click', function() {
    const password = passwordInput.value;
    if (password) {
      chrome.runtime.sendMessage({action: "unblock", password: password}, (response) => {
        if (response.success) {
          updateUI(false);
          passwordInput.value = '';
          errorDiv.style.display = 'none';
        } else {
          errorDiv.style.display = 'block';
        }
      });
    }
  });

  // Обработчик кнопки включения блокировки
  blockBtn.addEventListener('click', function() {
    chrome.runtime.sendMessage({action: "block"}, (response) => {
      if (response.success) {
        updateUI(true);
      }
    });
  });

  function updateUI(isBlocked) {
    if (isBlocked) {
      statusDiv.textContent = 'Блокировка активна';
      statusDiv.className = 'status blocked';
      unblockSection.style.display = 'block';
      blockSection.style.display = 'none';
    } else {
      statusDiv.textContent = 'Блокировка отключена';
      statusDiv.className = 'status unblocked';
      unblockSection.style.display = 'none';
      blockSection.style.display = 'block';
    }
  }
});