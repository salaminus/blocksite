// Сайт для блокировки (можно изменить)
const BLOCKED_SITE = "https://vk.com";
const PASSWORD = "1234"; // Пароль для отключения блокировки

// Переменная для отслеживания состояния блокировки
let isBlocked = true;

// Обработчик веб-запросов
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (isBlocked && details.url.includes(BLOCKED_SITE)) {
      return { redirectUrl: chrome.runtime.getURL("blocked.html") };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

// Обработчик сообщений от popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkStatus") {
    sendResponse({ isBlocked: isBlocked });
  } else if (request.action === "unblock" && request.password === PASSWORD) {
    isBlocked = false;
    sendResponse({ success: true });
  } else if (request.action === "block") {
    isBlocked = true;
    sendResponse({ success: true });
  } else if (request.action === "checkPassword" && request.password === PASSWORD) {
    sendResponse({ success: true });
  } else {
    sendResponse({ success: false });
  }
});

// Сохраняем состояние блокировки при перезагрузке
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['isBlocked'], (result) => {
    isBlocked = result.isBlocked !== undefined ? result.isBlocked : true;
  });
});

// Сохраняем состояние при изменении
setInterval(() => {
  chrome.storage.local.set({ isBlocked: isBlocked });
}, 1000);